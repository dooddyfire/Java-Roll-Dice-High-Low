import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.*;
public class RollingDiceGui extends JFrame {
	String guess;
	int diceOne;
	int diceTwo;
    public RollingDiceGui(){
        super("Rolling Double Dice");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(700, 700));
        pack();
        setResizable(false);
        setLocationRelativeTo(null);

        addGuiComponents();
    }

    private void addGuiComponents(){
    	
        JPanel jPanel = new JPanel();
        jPanel.setLayout(null);

        //1.Banner
        JLabel bannerImg = ImgService.loadImage("resources/banner.png");
        bannerImg.setBounds(45, 25, 600, 100);
        jPanel.add(bannerImg);


        //2. Dices
        JLabel diceOneImg = ImgService.loadImage("resources/dice1.png");
        diceOneImg.setBounds(100, 200, 200, 200);
        jPanel.add(diceOneImg);

        JLabel diceTwoImg = ImgService.loadImage("resources/dice1.png");
        diceTwoImg.setBounds(390, 200, 200, 200);
        jPanel.add(diceTwoImg);

        //3. Roll Button
        Random rand = new Random();
        JButton rollButton = new JButton("Roll!");
        
        
        JButton high_btn = new JButton("High"); 
        JButton low_btn = new JButton("Low");
        
        high_btn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

	             
	             JOptionPane.showMessageDialog(new JFrame(), "Guess High", "Guess High",
	            	        JOptionPane.INFORMATION_MESSAGE);
	             guess = "high";
			}
        	
        });
        
        
        high_btn.setBounds(400, 600, 200, 50);
        jPanel.add(high_btn);
        
        
        low_btn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
	             JOptionPane.showMessageDialog(new JFrame(), "Guess Low", "Guess Low",
	            	        JOptionPane.INFORMATION_MESSAGE);
	             guess = "low";
			}
        	
        });   
        low_btn.setBounds(200, 600, 200, 50);
        jPanel.add(low_btn);
        
        rollButton.setBounds(250, 550, 200, 50);
        rollButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                rollButton.setEnabled(false);

                // roll for 3 seconds
                long startTime = System.currentTimeMillis();
                Thread rollThread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        long endTime = System.currentTimeMillis();
                        try{
                            while((endTime - startTime)/1000F < 3){
                                // roll dice
                                diceOne = rand.nextInt(7 - 1 + 1) + 1;
                                diceTwo = rand.nextInt(7 - 1 + 1) + 1;

                                // update dice images
                                ImgService.updateImage(diceOneImg, "resources/dice" + diceOne + ".png");
                                ImgService.updateImage(diceTwoImg, "resources/dice" + diceTwo + ".png");

                                repaint();
                                revalidate();

                                // sleep thread
                                Thread.sleep(60);

                                endTime = System.currentTimeMillis();

                            }
                            
                            if( (int)diceOne + (int)diceTwo <= 6) {
               	             JOptionPane.showMessageDialog(new JFrame(), "Low : " ,"Result",
         	            	        JOptionPane.INFORMATION_MESSAGE);
                            	
                            }else if(diceOne + diceTwo > 6) {
                  	             JOptionPane.showMessageDialog(new JFrame(), "High : ", "Result",
              	            	        JOptionPane.INFORMATION_MESSAGE);
                            }
                            diceOne = 0; 
                            diceTwo = 0;
                            rollButton.setEnabled(true);
                        }catch(InterruptedException e){
                            System.out.println("Threading Error: " + e);
                        }
                    }
                });
                rollThread.start();
            }
        });
        jPanel.add(rollButton);
        
        this.getContentPane().add(jPanel);
    }
}
