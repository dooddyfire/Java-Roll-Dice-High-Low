package high_btn;

public interface addActionListener {

}
